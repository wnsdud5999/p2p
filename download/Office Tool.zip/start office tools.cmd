@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Office Tools\office tools menu.ps1"
