﻿사용 안내

가장 쉬운 실행 방법

1. 상위 폴더의 `start office tools.cmd` 실행
2. 번호 선택
3. `1. Create new` 또는 `2. Choose from file` 선택

메뉴 구성

1. DOCX generator
2. HWPX generator
3. XLSX generator
4. PPT generator
5. PDF editor

현재 폴더 구성

- 이 `Office Tools` 폴더 안에 실제 HTML / JS / 자동 실행 스크립트가 들어 있습니다.
- 바깥 폴더에는 `start office tools.cmd`만 두는 구조로 정리했습니다.

Create new 설명

- DOCX / HWPX / XLSX / PPT / PDF를 빈 문서 상태로 바로 엽니다.
- 이전 자동 불러오기 데이터가 남아 있지 않게 자동 소스도 같이 초기화합니다.

Choose from file 설명

- DOCX: `.docx`, `.doc`, `.txt`, `.md`, `.html`, `.json`
- HWPX: 현재는 `.txt`, `.md`, `.html`, `.json` 같은 소스 파일 위주
- XLSX: `.xlsx`, `.xls`, `.csv`, `.tsv`, `.txt`, `.json`
- PPT: `.pptx`, `.ppt`, `.txt`, `.md`, `.json`
- PDF: `.pdf`

자동 열기 기본 파일명

- DOCX: `auto-open.docx`, `auto-open.doc`
- XLSX: `auto-open.xlsx`, `auto-open.xls`
- PPT: `auto-open.pptx`, `auto-open.ppt`
- PDF: `auto-open.pdf`
- HWPX: `auto-open.hwpx.json`, `auto-open.hwpx.html`, `auto-open.hwpx.txt`, `auto-open.txt`

현재 제한 사항

- HWPX 생성기는 이미지와 표 기능이 현재 공사 중입니다.
- 그래서 HWPX에서는 이미지 / 표 삽입 및 내보내기를 막아 두었습니다.
- PDF 편집기는 원본 본문 재흐름 편집이 아니라 오버레이 편집에 가깝습니다.

참고

- 구형 `.doc`, `.ppt`, `.xls`는 PC에 해당 Office 프로그램이 설치되어 있으면 자동 변환 후 불러옵니다.
- 작업 중간중간 다운로드해서 저장하는 것을 권장합니다.
