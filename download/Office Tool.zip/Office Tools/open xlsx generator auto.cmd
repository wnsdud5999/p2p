@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0open office generator auto.ps1" -Mode xlsx -SourcePath "%~1"
