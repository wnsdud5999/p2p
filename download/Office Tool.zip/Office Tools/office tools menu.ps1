param()

$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path

function Get-EdgePath {
  @(
    "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
    "${env:ProgramFiles}\Microsoft\Edge\Application\msedge.exe"
  ) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1
}

function Open-ToolHtml([string]$FileName) {
  $path = [System.IO.Path]::GetFullPath((Join-Path $root $FileName))
  $uri = [System.Uri]::new($path).AbsoluteUri
  $edgePath = Get-EdgePath
  if ($edgePath) {
    Start-Process -FilePath $edgePath -ArgumentList @('--allow-file-access-from-files', $uri) | Out-Null
  } else {
    Start-Process $uri | Out-Null
  }
}

function Reset-AutoSource([string]$FileName, [string]$GlobalName) {
  $path = Join-Path $root $FileName
  Set-Content -LiteralPath $path -Value "window.$GlobalName = null;" -Encoding UTF8
}

function Start-NewDocument([string]$Mode) {
  switch ($Mode) {
    'docx' {
      Reset-AutoSource 'docx generator auto source.js' '__AUTO_DOCX_SOURCE'
      Open-ToolHtml 'docx generator.html'
    }
    'hwpx' {
      Reset-AutoSource 'hwpx generator auto source.js' '__AUTO_HWPX_SOURCE'
      Open-ToolHtml 'hwpx generator.html'
    }
    'xlsx' {
      Reset-AutoSource 'xlsx generator auto source.js' '__AUTO_XLSX_SOURCE'
      Open-ToolHtml 'xlsx generator.html'
    }
    'ppt' {
      Reset-AutoSource 'ppt generator auto source.js' '__AUTO_PPT_SOURCE'
      Open-ToolHtml 'ppt generator.html'
    }
    'pdf' {
      Open-ToolHtml 'pdf editor.html'
    }
  }
}

function Start-FromFile([string]$Mode) {
  $command = switch ($Mode) {
    'docx' { 'open docx generator auto.cmd' }
    'hwpx' { 'open hwpx generator auto.cmd' }
    'xlsx' { 'open xlsx generator auto.cmd' }
    'ppt' { 'open ppt generator auto.cmd' }
    'pdf' { 'open pdf editor auto.cmd' }
  }

  if (-not $command) { return }
  Start-Process -FilePath (Join-Path $root $command) | Out-Null
}

function Read-Choice([string]$Prompt) {
  (Read-Host $Prompt).Trim()
}

while ($true) {
  Clear-Host
  Write-Host "Office tools launcher"
  Write-Host ""
  Write-Host "1. DOCX generator"
  Write-Host "2. HWPX generator"
  Write-Host "3. XLSX generator"
  Write-Host "4. PPT generator"
  Write-Host "5. PDF editor"
  Write-Host "0. Exit"
  Write-Host ""

  $mainChoice = Read-Choice "Choose a tool"
  $mode = switch ($mainChoice) {
    '1' { 'docx' }
    '2' { 'hwpx' }
    '3' { 'xlsx' }
    '4' { 'ppt' }
    '5' { 'pdf' }
    '0' { break }
    default { $null }
  }

  if (-not $mode) {
    Write-Host ""
    Write-Host "Please enter a valid number." -ForegroundColor Yellow
    Start-Sleep -Seconds 1
    continue
  }

  while ($true) {
    Clear-Host
    $label = switch ($mode) {
      'docx' { 'DOCX generator' }
      'hwpx' { 'HWPX generator' }
      'xlsx' { 'XLSX generator' }
      'ppt' { 'PPT generator' }
      'pdf' { 'PDF editor' }
    }

    Write-Host $label
    Write-Host ""
    Write-Host "1. Create new"
    Write-Host "2. Choose from file"
    Write-Host "0. Back"
    Write-Host ""

    if ($mode -eq 'hwpx') {
      Write-Host "HWPX choose-from-file currently supports source files such as txt / md / html / json." -ForegroundColor DarkYellow
      Write-Host ""
    }

    $subChoice = Read-Choice "Choose an action"
    if ($subChoice -eq '0') { break }

    if ($subChoice -eq '1') {
      Start-NewDocument $mode
      break
    }

    if ($subChoice -eq '2') {
      Start-FromFile $mode
      break
    }

    Write-Host ""
    Write-Host "Please enter a valid number." -ForegroundColor Yellow
    Start-Sleep -Seconds 1
  }
}
