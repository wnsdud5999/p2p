@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0open office generator auto.ps1" -Mode hwpx %*
