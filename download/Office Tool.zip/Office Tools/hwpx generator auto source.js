window.__AUTO_HWPX_SOURCE = window.__AUTO_HWPX_SOURCE || null;
