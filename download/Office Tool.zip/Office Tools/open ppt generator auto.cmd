@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0open office generator auto.ps1" -Mode ppt -SourcePath "%~1"
