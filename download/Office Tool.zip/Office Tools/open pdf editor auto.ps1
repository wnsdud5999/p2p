param(
  [string]$Pdf = "auto-open.pdf",
  [switch]$NoBrowser
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Windows.Forms

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$editorPath = Join-Path $root "pdf editor auto.html"
$sourcePath = Join-Path $root "pdf editor auto source.js"
$pdfPath = if ([string]::IsNullOrWhiteSpace($Pdf)) {
  ""
} elseif ([System.IO.Path]::IsPathRooted($Pdf)) {
  $Pdf
} else {
  Join-Path $root $Pdf
}

if ([string]::IsNullOrWhiteSpace($pdfPath) -or -not (Test-Path -LiteralPath $pdfPath -PathType Leaf)) {
  $defaultCandidate = Join-Path $root 'auto-open.pdf'
  if (Test-Path -LiteralPath $defaultCandidate -PathType Leaf) {
    $pdfPath = $defaultCandidate
  } else {
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.InitialDirectory = $root
    $dialog.Filter = 'PDF files (*.pdf)|*.pdf|All files (*.*)|*.*'
    $dialog.Title = 'Choose a PDF file for PDF editor'
    $dialog.Multiselect = $false
    if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
      $pdfPath = $dialog.FileName
    } else {
      $pdfPath = ''
    }
  }
}

$editorFull = [System.IO.Path]::GetFullPath($editorPath)
$pdfFull = [System.IO.Path]::GetFullPath($pdfPath)
$editorUri = [System.Uri]::new($editorFull).AbsoluteUri
$launchUrl = $editorUri

$edgeCandidates = @(
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
  "${env:ProgramFiles}\Microsoft\Edge\Application\msedge.exe"
)
$edgePath = $edgeCandidates | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1

Write-Host "Editor file: $editorFull"
Write-Host "Configured PDF: $pdfFull"
if (Test-Path -LiteralPath $pdfFull -PathType Leaf) {
  $bytesBase64 = [Convert]::ToBase64String([System.IO.File]::ReadAllBytes($pdfFull))
  $payload = [pscustomobject]@{
    name = [System.IO.Path]::GetFileName($pdfFull)
    path = $pdfFull
    updatedAt = (Get-Date).ToString("o")
    bytesBase64 = $bytesBase64
  } | ConvertTo-Json -Compress -Depth 4

  Set-Content -LiteralPath $sourcePath -Value "window.__AUTO_PDF_SOURCE = $payload;" -Encoding UTF8
  Write-Host "Source PDF indexed."
  Write-Host "Source file: $sourcePath"
} else {
  Set-Content -LiteralPath $sourcePath -Value "window.__AUTO_PDF_SOURCE = null;" -Encoding UTF8
  Write-Host "Source PDF not selected. Indexed source was reset to a small stub."
}

if ($NoBrowser) {
  return
}

if ($edgePath) {
  Start-Process -FilePath $edgePath -ArgumentList @("--allow-file-access-from-files", $launchUrl) | Out-Null
} else {
  Start-Process $launchUrl | Out-Null
}
