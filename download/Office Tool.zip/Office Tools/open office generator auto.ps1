﻿param(
  [ValidateSet("docx", "ppt", "xlsx", "hwpx")]
  [string]$Mode,
  [string]$SourcePath = "",
  [switch]$NoBrowser
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -AssemblyName System.Windows.Forms

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$tempArtifacts = New-Object System.Collections.Generic.List[string]

function ConvertTo-Base64Utf8([string]$Value) {
  [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes([string]$Value))
}

function Attr($Node, [string]$LocalName, [string]$NamespaceUri = "") {
  if ($null -eq $Node) { return "" }
  if ([string]::IsNullOrWhiteSpace($NamespaceUri)) { return [string]$Node.GetAttribute($LocalName) }
  return [string]$Node.GetAttribute($LocalName, $NamespaceUri)
}

function Escape-Html([string]$Value) {
  [System.Net.WebUtility]::HtmlEncode([string]$Value)
}

function Package-Path([string]$BaseDirectory, [string]$Target) {
  if ([string]::IsNullOrWhiteSpace($Target)) { return "" }
  if ($Target.StartsWith("/")) { return $Target.TrimStart("/") }
  $basePrefix = if ($BaseDirectory) { "$($BaseDirectory.TrimEnd('/'))/" } else { "" }
  $baseUri = [System.Uri]::new("http://package/$basePrefix")
  $targetUri = [System.Uri]::new($baseUri, $Target)
  $targetUri.AbsolutePath.TrimStart("/")
}

function New-Ns($Xml, [hashtable]$Mappings) {
  if ($Xml -is [string] -and -not [string]::IsNullOrWhiteSpace($Xml)) {
    [xml]$Xml = $Xml
  }
  if ($null -eq $Xml -or $null -eq $Xml.NameTable) {
    $fallbackDocument = New-Object System.Xml.XmlDocument
    $fallbackDocument.LoadXml('<root />')
    $Xml = $fallbackDocument
  }
  $manager = [System.Xml.XmlNamespaceManager]::new($Xml.NameTable)
  foreach ($key in $Mappings.Keys) {
    $manager.AddNamespace($key, $Mappings[$key])
  }
  $manager
}

function Open-Zip([string]$Path) {
  $stream = [System.IO.File]::Open($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
  try {
    $archive = [System.IO.Compression.ZipArchive]::new($stream, [System.IO.Compression.ZipArchiveMode]::Read, $false)
    [pscustomobject]@{ Stream = $stream; Archive = $archive }
  } catch {
    $stream.Dispose()
    throw
  }
}

function Close-Zip($Context) {
  if ($Context) {
    if ($Context.Archive) { $Context.Archive.Dispose() }
    if ($Context.Stream) { $Context.Stream.Dispose() }
  }
}

function Zip-Text($Archive, [string]$EntryName) {
  $entry = $null
  foreach ($candidate in @($EntryName, $EntryName.Replace('\', '/'), $EntryName.Replace('/', '\')) | Select-Object -Unique) {
    $entry = $Archive.GetEntry($candidate)
    if ($entry) { break }
  }
  if ($null -eq $entry) { return $null }
  $reader = New-Object System.IO.StreamReader($entry.Open(), $true)
  try { $reader.ReadToEnd() } finally { $reader.Dispose() }
}

function Zip-Bytes($Archive, [string]$EntryName) {
  $entry = $null
  foreach ($candidate in @($EntryName, $EntryName.Replace('\', '/'), $EntryName.Replace('/', '\')) | Select-Object -Unique) {
    $entry = $Archive.GetEntry($candidate)
    if ($entry) { break }
  }
  if ($null -eq $entry) { return $null }
  $stream = $entry.Open()
  $buffer = New-Object System.IO.MemoryStream
  try {
    $stream.CopyTo($buffer)
    $buffer.ToArray()
  } finally {
    $buffer.Dispose()
    $stream.Dispose()
  }
}

function Rel-Map($Archive, [string]$RelationshipsPath, [string]$BaseDirectory) {
  $map = @{}
  $text = Zip-Text $Archive $RelationshipsPath
  if ([string]::IsNullOrWhiteSpace($text)) { return $map }
  [xml]$xml = $text
  foreach ($rel in $xml.Relationships.Relationship) {
    $id = [string]$rel.Id
    $target = [string]$rel.Target
    if ($id -and $target) {
      $map[$id] = Package-Path $BaseDirectory $target
    }
  }
  $map
}

function Mime-Type([string]$Extension) {
  $safeExtension = if ($null -ne $Extension) { $Extension } else { "" }
  switch ($safeExtension.ToLowerInvariant()) {
    ".png" { "image/png" }
    ".jpg" { "image/jpeg" }
    ".jpeg" { "image/jpeg" }
    ".gif" { "image/gif" }
    ".bmp" { "image/bmp" }
    ".webp" { "image/webp" }
    default { "application/octet-stream" }
  }
}

function Data-Url([byte[]]$Bytes, [string]$Extension) {
  if ($null -eq $Bytes -or $Bytes.Length -eq 0) { return $null }
  $mimeType = Mime-Type $Extension
  [pscustomobject]@{
    MimeType = $mimeType
    Url = "data:$mimeType;base64,$([Convert]::ToBase64String($Bytes))"
  }
}

function Number-Attr($Node, [string]$AttributeName, [double]$Fallback) {
  if ($Node -and $Node.GetAttribute($AttributeName)) {
    return [double]$Node.GetAttribute($AttributeName)
  }
  return $Fallback
}

function Release-ComObject($ComObject) {
  if ($null -eq $ComObject) { return }
  try {
    if ([System.Runtime.InteropServices.Marshal]::IsComObject($ComObject)) {
      [void][System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($ComObject)
    }
  } catch {
  }
}

function Convert-LegacyOfficeFile([string]$LegacyPath, [string]$TargetExtension) {
  $extension = [System.IO.Path]::GetExtension($LegacyPath).ToLowerInvariant()
  $tempDirectory = Join-Path $root ("_auto_import_" + [Guid]::NewGuid().ToString("N"))
  [System.IO.Directory]::CreateDirectory($tempDirectory) | Out-Null
  [void]$tempArtifacts.Add($tempDirectory)
  $targetPath = Join-Path $tempDirectory ("converted$TargetExtension")

  switch ($extension) {
    ".doc" {
      $app = $null
      $document = $null
      try {
        $app = New-Object -ComObject Word.Application
        $app.Visible = $false
        $app.DisplayAlerts = 0
        $document = $app.Documents.Open($LegacyPath, $false, $true)
        $document.SaveAs([ref]$targetPath, [ref]16)
      } finally {
        if ($document) { try { $document.Close([ref]$false) | Out-Null } catch {} ; Release-ComObject $document }
        if ($app) { try { $app.Quit() | Out-Null } catch {} ; Release-ComObject $app }
      }
      return $targetPath
    }
    ".ppt" {
      $app = $null
      $presentation = $null
      try {
        $app = New-Object -ComObject PowerPoint.Application
        $presentation = $app.Presentations.Open($LegacyPath, $true, $false, $false)
        $presentation.SaveAs($targetPath, 24)
      } finally {
        if ($presentation) { try { $presentation.Close() } catch {} ; Release-ComObject $presentation }
        if ($app) { try { $app.Quit() } catch {} ; Release-ComObject $app }
      }
      return $targetPath
    }
    ".xls" {
      $app = $null
      $workbook = $null
      try {
        $app = New-Object -ComObject Excel.Application
        $app.Visible = $false
        $app.DisplayAlerts = $false
        $workbook = $app.Workbooks.Open($LegacyPath)
        $workbook.SaveAs($targetPath, 51)
      } finally {
        if ($workbook) { try { $workbook.Close($false) | Out-Null } catch {} ; Release-ComObject $workbook }
        if ($app) { try { $app.Quit() | Out-Null } catch {} ; Release-ComObject $app }
      }
      return $targetPath
    }
    default { throw "Legacy import is not supported for: $extension" }
  }
}

function Convert-DocxContent($Nodes) {
  $parts = New-Object System.Collections.Generic.List[string]
  $listItems = New-Object System.Collections.Generic.List[string]
  foreach ($node in $Nodes) {
    switch ($node.LocalName) {
      "p" {
        $texts = @($node.SelectNodes(".//*[local-name()='t']") | ForEach-Object { $_.InnerText })
        $text = ($texts -join "")
        if (-not $text -and $node.SelectSingleNode(".//*[local-name()='drawing']")) { $text = '[Image]' }
        $escaped = if ($text) { Escape-Html $text } else { '<br>' }
        if ($node.SelectSingleNode("./*[local-name()='pPr']/*[local-name()='numPr']")) {
          [void]$listItems.Add("<li>$escaped</li>")
        } else {
          if ($listItems.Count -gt 0) {
            [void]$parts.Add("<ul>$($listItems -join '')</ul>")
            $listItems.Clear()
          }
          $styleId = Attr ($node.SelectSingleNode("./*[local-name()='pPr']/*[local-name()='pStyle']")) 'val' 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
          $tagName = switch ($styleId) { 'Heading1' { 'h1' } 'Heading2' { 'h2' } default { 'p' } }
          [void]$parts.Add("<$tagName>$escaped</$tagName>")
        }
      }
      "tbl" {
        if ($listItems.Count -gt 0) {
          [void]$parts.Add("<ul>$($listItems -join '')</ul>")
          $listItems.Clear()
        }
        $rows = New-Object System.Collections.Generic.List[string]
        foreach ($row in $node.SelectNodes("./*[local-name()='tr']")) {
          $cells = New-Object System.Collections.Generic.List[string]
          foreach ($cell in $row.SelectNodes("./*[local-name()='tc']")) {
            $cellText = @($cell.SelectNodes(".//*[local-name()='t']") | ForEach-Object { $_.InnerText }) -join ' '
            if (-not $cellText) { $cellText = ' ' }
            [void]$cells.Add("<td><p>$(Escape-Html $cellText)</p></td>")
          }
          [void]$rows.Add("<tr>$($cells -join '')</tr>")
        }
        [void]$parts.Add("<table><tbody>$($rows -join '')</tbody></table>")
      }
    }
  }
  if ($listItems.Count -gt 0) {
    [void]$parts.Add("<ul>$($listItems -join '')</ul>")
  }
  $parts -join ''
}

function Import-DocxPayload([string]$Path, [string]$DisplayFileName) {
  $sourcePath = if ([System.IO.Path]::GetExtension($Path).ToLowerInvariant() -eq '.doc') { Convert-LegacyOfficeFile $Path '.docx' } else { $Path }
  $context = Open-Zip $sourcePath
  try {
    [xml]$documentXml = Zip-Text $context.Archive 'word/document.xml'
    $body = $documentXml.SelectSingleNode("/*[local-name()='document']/*[local-name()='body']")
    $html = if ($body) { Convert-DocxContent $body.ChildNodes } else { '' }
    if (-not $html) { $html = '<p><br></p>' }
    @{ fileName = $DisplayFileName; html = $html }
  } finally {
    Close-Zip $context
  }
}

function Get-PptTextStyle($ShapeNode) {
  $style = @{ fontFamily = 'Arial'; fontSize = 18; bold = $false; italic = $false; underline = $false; color = '000000' }
  $rPr = $ShapeNode.SelectSingleNode(".//*[local-name()='r']/*[local-name()='rPr']")
  if (-not $rPr) { return $style }
  $style.bold = $rPr.GetAttribute('b') -eq '1'
  $style.italic = $rPr.GetAttribute('i') -eq '1'
  $style.underline = $rPr.GetAttribute('u') -and $rPr.GetAttribute('u') -ne 'none'
  $sizeValue = 0.0
  if ([double]::TryParse($rPr.GetAttribute('sz'), [System.Globalization.NumberStyles]::Any, [System.Globalization.CultureInfo]::InvariantCulture, [ref]$sizeValue) -and $sizeValue -gt 0) {
    $style.fontSize = [Math]::Round($sizeValue / 100, 2)
  }
  $latin = $rPr.SelectSingleNode("./*[local-name()='latin']")
  if ($latin) { $style.fontFamily = $latin.GetAttribute('typeface') }
  $color = $rPr.SelectSingleNode("./*[local-name()='solidFill']/*[local-name()='srgbClr']")
  if ($color) {
    $style.color = if ($color.GetAttribute('val')) { $color.GetAttribute('val') } else { '000000' }
  }
  $style
}

function Import-PptPayload([string]$Path, [string]$DisplayFileName) {
  $sourcePath = if ([System.IO.Path]::GetExtension($Path).ToLowerInvariant() -eq '.ppt') { Convert-LegacyOfficeFile $Path '.pptx' } else { $Path }
  $context = Open-Zip $sourcePath
  try {
    [xml]$presentationXml = Zip-Text $context.Archive 'ppt/presentation.xml'
    $slideSize = $presentationXml.SelectSingleNode("/*[local-name()='presentation']/*[local-name()='sldSz']")
    $slideWidthEmu = Number-Attr $slideSize 'cx' 12192000
    $slideHeightEmu = Number-Attr $slideSize 'cy' 6858000
    $scaleX = 960 / [Math]::Max(1, $slideWidthEmu)
    $scaleY = 540 / [Math]::Max(1, $slideHeightEmu)
    $rels = Rel-Map $context.Archive 'ppt/_rels/presentation.xml.rels' 'ppt/'
    $slides = New-Object System.Collections.Generic.List[object]

    foreach ($slideIdNode in $presentationXml.SelectNodes("/*[local-name()='presentation']/*[local-name()='sldIdLst']/*[local-name()='sldId']")) {
      $rid = Attr $slideIdNode 'id' 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
      if (-not $rid -or -not $rels.ContainsKey($rid)) { continue }
      $slidePath = $rels[$rid]
      [xml]$slideXml = Zip-Text $context.Archive $slidePath
      $slideBase = ([System.IO.Path]::GetDirectoryName($slidePath) -replace '\\', '/')
      $slideRelsPath = "${slideBase}_rels/$([System.IO.Path]::GetFileName($slidePath)).rels"
      $slideRels = Rel-Map $context.Archive $slideRelsPath $slideBase
      $items = New-Object System.Collections.Generic.List[object]

      foreach ($child in $slideXml.SelectNodes("/*[local-name()='sld']/*[local-name()='cSld']/*[local-name()='spTree']/*")) {
        switch ($child.LocalName) {
          'sp' {
            $paragraphs = @($child.SelectNodes("./*[local-name()='txBody']/*[local-name()='p']") | ForEach-Object { (@($_.SelectNodes(".//*[local-name()='t']") | ForEach-Object { $_.InnerText }) -join '') }) | Where-Object { $_ -ne '' }
            if ($paragraphs.Count -eq 0) { continue }
            $xfrm = $child.SelectSingleNode("./*[local-name()='spPr']/*[local-name()='xfrm']")
            $off = if ($xfrm) { $xfrm.SelectSingleNode("./*[local-name()='off']") } else { $null }
            $ext = if ($xfrm) { $xfrm.SelectSingleNode("./*[local-name()='ext']") } else { $null }
            $ph = $child.SelectSingleNode("./*[local-name()='nvSpPr']/*[local-name()='nvPr']/*[local-name()='ph']")
            $phType = if ($ph) { $ph.GetAttribute('type') } else { '' }
            $role = if ($phType -in @('title', 'ctrTitle', 'subTitle')) { 'title' } elseif ($phType) { 'body' } else { 'textbox' }
            $style = Get-PptTextStyle $child
            [void]$items.Add([ordered]@{
              type = 'text'
              role = $role
              x = [Math]::Round((Number-Attr $off 'x' 762000) * $scaleX)
              y = [Math]::Round((Number-Attr $off 'y' 762000) * $scaleY)
              w = [Math]::Max(120, [Math]::Round((Number-Attr $ext 'cx' 3048000) * $scaleX))
              h = [Math]::Max(48, [Math]::Round((Number-Attr $ext 'cy' 1143000) * $scaleY))
              text = ($paragraphs -join "`n")
              fontFamily = $style.fontFamily
              fontSize = $style.fontSize
              bold = $style.bold
              italic = $style.italic
              underline = $style.underline
              color = $style.color
            })
          }
          'pic' {
            $blip = $child.SelectSingleNode(".//*[local-name()='blip']")
            $rid = Attr $blip 'embed' 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
            if (-not $rid -or -not $slideRels.ContainsKey($rid)) { continue }
            $entryPath = $slideRels[$rid]
            $bytes = Zip-Bytes $context.Archive $entryPath
            $data = Data-Url $bytes ([System.IO.Path]::GetExtension($entryPath))
            if (-not $data) { continue }
            $xfrm = $child.SelectSingleNode("./*[local-name()='spPr']/*[local-name()='xfrm']")
            $off = if ($xfrm) { $xfrm.SelectSingleNode("./*[local-name()='off']") } else { $null }
            $ext = if ($xfrm) { $xfrm.SelectSingleNode("./*[local-name()='ext']") } else { $null }
            $w = [Math]::Max(120, [Math]::Round((Number-Attr $ext 'cx' 3048000) * $scaleX))
            $h = [Math]::Max(90, [Math]::Round((Number-Attr $ext 'cy' 2286000) * $scaleY))
            [void]$items.Add([ordered]@{
              type = 'image'
              x = [Math]::Round((Number-Attr $off 'x' 1524000) * $scaleX)
              y = [Math]::Round((Number-Attr $off 'y' 1524000) * $scaleY)
              w = $w
              h = $h
              initialX = [Math]::Round((Number-Attr $off 'x' 1524000) * $scaleX)
              initialY = [Math]::Round((Number-Attr $off 'y' 1524000) * $scaleY)
              initialW = $w
              initialH = $h
              src = $data.Url
              mimeType = $data.MimeType
              name = if ([System.IO.Path]::GetFileNameWithoutExtension($entryPath)) { [System.IO.Path]::GetFileNameWithoutExtension($entryPath) } else { 'Image' }
              sourceWidth = $w
              sourceHeight = $h
            })
          }
        }
      }

      [void]$slides.Add([ordered]@{
        layout = if (($items | Where-Object { $_.type -eq 'text' }).Count -le 1) { 'title-only' } else { 'title-body' }
        items = $items
      })
    }

    @{ fileName = $DisplayFileName; slides = $slides }
  } finally {
    Close-Zip $context
  }
}

function Cell-Pos([string]$Reference) {
  if ($Reference -notmatch '^([A-Z]+)(\d+)$') { return $null }
  $letters = $matches[1]
  $row = [int]$matches[2] - 1
  $col = 0
  foreach ($char in $letters.ToCharArray()) {
    $col = ($col * 26) + ([int][char]$char - [int][char]'A' + 1)
  }
  @{ Row = $row; Col = $col - 1 }
}

function Xlsx-SharedStrings($Archive) {
  $text = Zip-Text $Archive 'xl/sharedStrings.xml'
  if ([string]::IsNullOrWhiteSpace($text)) { return @() }
  [xml]$xml = $text
  @($xml.SelectNodes("/*[local-name()='sst']/*[local-name()='si']") | ForEach-Object { (@($_.SelectNodes(".//*[local-name()='t']") | ForEach-Object { $_.InnerText }) -join '') })
}

function Xlsx-CellText($CellNode, $SharedStrings) {
  $type = $CellNode.GetAttribute('t')
  $valueNode = $CellNode.SelectSingleNode("./*[local-name()='v']")
  switch ($type) {
    's' {
      $index = 0
      if ($valueNode -and [int]::TryParse($valueNode.InnerText, [ref]$index) -and $index -ge 0 -and $index -lt $SharedStrings.Count) {
        return $SharedStrings[$index]
      }
      return ''
    }
    'inlineStr' {
      return (@($CellNode.SelectNodes(".//*[local-name()='is']//*[local-name()='t']") | ForEach-Object { $_.InnerText }) -join '')
    }
    default {
      if ($valueNode) { return $valueNode.InnerText }
      return ''
    }
  }
}

function Import-XlsxPayload([string]$Path, [string]$DisplayFileName) {
  $sourcePath = if ([System.IO.Path]::GetExtension($Path).ToLowerInvariant() -eq '.xls') { Convert-LegacyOfficeFile $Path '.xlsx' } else { $Path }
  $context = Open-Zip $sourcePath
  try {
    [xml]$workbookXml = Zip-Text $context.Archive 'xl/workbook.xml'
    $rels = Rel-Map $context.Archive 'xl/_rels/workbook.xml.rels' 'xl/'
    $sharedStrings = Xlsx-SharedStrings $context.Archive
    $sheets = New-Object System.Collections.Generic.List[object]

    foreach ($sheetNode in $workbookXml.SelectNodes("/*[local-name()='workbook']/*[local-name()='sheets']/*[local-name()='sheet']")) {
      $rid = Attr $sheetNode 'id' 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
      if (-not $rid -or -not $rels.ContainsKey($rid)) { continue }
      $sheetPath = $rels[$rid]
      [xml]$sheetXml = Zip-Text $context.Archive $sheetPath
      $cellMap = @{}
      $maxRow = 1
      $maxCol = 1
      foreach ($cellNode in $sheetXml.SelectNodes("/*[local-name()='worksheet']/*[local-name()='sheetData']/*[local-name()='row']/*[local-name()='c']")) {
        $pos = Cell-Pos $cellNode.GetAttribute('r')
        if ($null -eq $pos) { continue }
        $maxRow = [Math]::Max($maxRow, $pos.Row + 1)
        $maxCol = [Math]::Max($maxCol, $pos.Col + 1)
        $cellMap["$($pos.Row),$($pos.Col)"] = Xlsx-CellText $cellNode $sharedStrings
      }
      $columnWidths = New-Object System.Collections.Generic.List[int]
      for ($index = 0; $index -lt $maxCol; $index++) { [void]$columnWidths.Add(116) }
      foreach ($columnNode in $sheetXml.SelectNodes("/*[local-name()='worksheet']/*[local-name()='cols']/*[local-name()='col']")) {
        $min = [int]$columnNode.GetAttribute('min')
        $max = [int]$columnNode.GetAttribute('max')
        $widthValue = 0.0
        if (-not [double]::TryParse($columnNode.GetAttribute('width'), [System.Globalization.NumberStyles]::Any, [System.Globalization.CultureInfo]::InvariantCulture, [ref]$widthValue)) {
          $widthValue = 15.86
        }
        $pixelWidth = [Math]::Max(72, [Math]::Round(($widthValue * 7) + 5))
        for ($col = ($min - 1); $col -le ($max - 1); $col++) {
          while ($columnWidths.Count -le $col) { [void]$columnWidths.Add(116) }
          $columnWidths[$col] = $pixelWidth
        }
      }
      $rows = New-Object System.Collections.Generic.List[object]
      for ($rowIndex = 0; $rowIndex -lt $maxRow; $rowIndex++) {
        $rowValues = New-Object System.Collections.Generic.List[object]
        for ($colIndex = 0; $colIndex -lt $maxCol; $colIndex++) {
          $key = "$rowIndex,$colIndex"
          if ($cellMap.ContainsKey($key)) {
            [void]$rowValues.Add(@{ value = $cellMap[$key] })
          } else {
            [void]$rowValues.Add('')
          }
        }
        [void]$rows.Add($rowValues)
      }
      [void]$sheets.Add([ordered]@{ name = if ($sheetNode.GetAttribute('name')) { $sheetNode.GetAttribute('name') } else { 'Sheet1' }; data = $rows; columnWidths = $columnWidths })
    }
    @{ fileName = $DisplayFileName; sheets = $sheets }
  } finally {
    Close-Zip $context
  }
}

$config = switch ($Mode) {
  'docx' {
    @{
      Editor = 'docx generator.html'
      SourceJs = 'docx generator auto source.js'
      Global = '__AUTO_DOCX_SOURCE'
      DefaultFiles = @('auto-open.docx', 'auto-open.doc')
      Filter = 'Word files (*.docx;*.doc)|*.docx;*.doc|Generator source files (*.txt;*.md;*.html;*.json)|*.txt;*.md;*.html;*.json|All files (*.*)|*.*'
      Title = 'Choose a Word file for DOCX generator'
    }
  }
  'ppt' {
    @{
      Editor = 'ppt generator.html'
      SourceJs = 'ppt generator auto source.js'
      Global = '__AUTO_PPT_SOURCE'
      DefaultFiles = @('auto-open.pptx', 'auto-open.ppt')
      Filter = 'PowerPoint files (*.pptx;*.ppt)|*.pptx;*.ppt|Generator source files (*.txt;*.md;*.json)|*.txt;*.md;*.json|All files (*.*)|*.*'
      Title = 'Choose a PowerPoint file for PPT generator'
    }
  }
  'xlsx' {
    @{
      Editor = 'xlsx generator.html'
      SourceJs = 'xlsx generator auto source.js'
      Global = '__AUTO_XLSX_SOURCE'
      DefaultFiles = @('auto-open.xlsx', 'auto-open.xls')
      Filter = 'Excel files (*.xlsx;*.xls)|*.xlsx;*.xls|Generator source files (*.csv;*.tsv;*.txt;*.json)|*.csv;*.tsv;*.txt;*.json|All files (*.*)|*.*'
      Title = 'Choose an Excel file for XLSX generator'
    }
  }
  'hwpx' {
    @{
      Editor = 'hwpx generator.html'
      SourceJs = 'hwpx generator auto source.js'
      Global = '__AUTO_HWPX_SOURCE'
      DefaultFiles = @('auto-open.hwpx.json', 'auto-open.hwpx.html', 'auto-open.hwpx.txt', 'auto-open.txt')
      Filter = 'HWPX generator source files (*.txt;*.md;*.html;*.json)|*.txt;*.md;*.html;*.json|All files (*.*)|*.*'
      Title = 'Choose a source file for HWPX generator'
    }
  }
}

try {
  if (-not $SourcePath) {
    foreach ($defaultName in $config.DefaultFiles) {
      $candidate = Join-Path $root $defaultName
      if (Test-Path -LiteralPath $candidate -PathType Leaf) {
        $SourcePath = $candidate
        break
      }
    }
  }

  if (-not $SourcePath) {
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.InitialDirectory = $root
    $dialog.Filter = $config.Filter
    $dialog.Title = $config.Title
    $dialog.Multiselect = $false
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return }
    $SourcePath = $dialog.FileName
  }

  $sourceFull = if ([System.IO.Path]::IsPathRooted($SourcePath)) {
    [System.IO.Path]::GetFullPath($SourcePath)
  } else {
    [System.IO.Path]::GetFullPath((Join-Path $root $SourcePath))
  }

  if (-not (Test-Path -LiteralPath $sourceFull -PathType Leaf)) {
    throw "Source file not found: $sourceFull"
  }

  $sourceExtension = [System.IO.Path]::GetExtension($sourceFull).ToLowerInvariant()
  $displayFileName = [System.IO.Path]::GetFileNameWithoutExtension($sourceFull)

  if (($Mode -eq 'docx' -and $sourceExtension -in @('.docx', '.doc')) -or
      ($Mode -eq 'ppt' -and $sourceExtension -in @('.pptx', '.ppt')) -or
      ($Mode -eq 'xlsx' -and $sourceExtension -in @('.xlsx', '.xls'))) {
    $importedPayload = switch ($Mode) {
      'docx' { Import-DocxPayload $sourceFull $displayFileName }
      'ppt' { Import-PptPayload $sourceFull $displayFileName }
      'xlsx' { Import-XlsxPayload $sourceFull $displayFileName }
    }
    $wrappedSource = [ordered]@{
      name = [System.IO.Path]::GetFileName($sourceFull)
      fileName = $displayFileName
      path = $sourceFull
      extension = 'json'
      updatedAt = (Get-Date).ToString('o')
      textBase64 = ConvertTo-Base64Utf8 (($importedPayload | ConvertTo-Json -Compress -Depth 20))
    }
  } else {
    $wrappedSource = [ordered]@{
      name = [System.IO.Path]::GetFileName($sourceFull)
      fileName = $displayFileName
      path = $sourceFull
      extension = [System.IO.Path]::GetExtension($sourceFull).TrimStart('.').ToLowerInvariant()
      updatedAt = (Get-Date).ToString('o')
      textBase64 = [Convert]::ToBase64String([System.IO.File]::ReadAllBytes($sourceFull))
    }
  }

  $editorFull = [System.IO.Path]::GetFullPath((Join-Path $root $config.Editor))
  $sourceJsFull = [System.IO.Path]::GetFullPath((Join-Path $root $config.SourceJs))
  $launchUrl = [System.Uri]::new($editorFull).AbsoluteUri
  $payloadJson = $wrappedSource | ConvertTo-Json -Compress -Depth 20
  Set-Content -LiteralPath $sourceJsFull -Value "window.$($config.Global) = $payloadJson;" -Encoding UTF8

  Write-Host "Editor file: $editorFull"
  Write-Host "Loaded source: $sourceFull"
  Write-Host "Indexed source: $sourceJsFull"

  if ($NoBrowser) { return }

  $edgeCandidates = @(
    "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
    "${env:ProgramFiles}\Microsoft\Edge\Application\msedge.exe"
  )
  $edgePath = $edgeCandidates | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1

  if ($edgePath) {
    Start-Process -FilePath $edgePath -ArgumentList @('--allow-file-access-from-files', $launchUrl) | Out-Null
  } else {
    Start-Process $launchUrl | Out-Null
  }
} finally {
  foreach ($artifact in $tempArtifacts) {
    if (Test-Path -LiteralPath $artifact) {
      try { Remove-Item -LiteralPath $artifact -Recurse -Force } catch {}
    }
  }
}
