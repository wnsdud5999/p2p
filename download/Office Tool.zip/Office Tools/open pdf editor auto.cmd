@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0open pdf editor auto.ps1" %*
