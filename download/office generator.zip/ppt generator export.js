(function () {
  if (!window.PPT_TEMPLATE || !window.PPT_TEMPLATE.staticFiles) {
    return;
  }

  const TEMPLATE_STATIC_FILES = window.PPT_TEMPLATE.staticFiles;
  const SLIDE_LAYOUT_TARGET = window.PPT_TEMPLATE.slideLayoutTarget || "../slideLayouts/slideLayout6.xml";

  function buildTextParagraphsXml(item) {
    const lines = String(item.text || "").replace(/\r\n?/g, "\n").split("\n");
    const size = Math.max(800, Math.round((item.fontSize || 18) * 100));
    return lines.map(line => {
      const isBullet = /^\s*-\s+/.test(line);
      const cleanLine = isBullet ? line.replace(/^\s*-\s+/, "") : line;
      if (!cleanLine && !isBullet) {
        return `<a:p><a:endParaRPr lang="en-US" sz="${size}"/></a:p>`;
      }

      const bulletXml = isBullet
        ? `<a:pPr marL="342900" indent="-171450"><a:buChar char="&#8226;"/></a:pPr>`
        : "";

      return `<a:p>${bulletXml}<a:r>${buildTextRunPropertiesXml(item)}${wrapTextValueXml(cleanLine || " ")}</a:r><a:endParaRPr lang="en-US" sz="${size}"${item.bold ? ' b="1"' : ""}/></a:p>`;
    }).join("");
  }

  function buildPresentationXml(slidesData) {
    const slideIdsXml = slidesData.length
      ? `<p:sldIdLst>${slidesData.map((slide, index) => `<p:sldId id="${256 + index}" r:id="rId${index + 2}"/>`).join("")}</p:sldIdLst>`
      : "";

    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:presentation xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" saveSubsetFonts="1">
  <p:sldMasterIdLst>
    <p:sldMasterId id="2147483648" r:id="rId1"/>
  </p:sldMasterIdLst>
  ${slideIdsXml}
  <p:sldSz cx="12192000" cy="6858000"/>
  <p:notesSz cx="6858000" cy="9144000"/>
  <p:defaultTextStyle>
    <a:defPPr>
      <a:defRPr lang="en-US"/>
    </a:defPPr>
  </p:defaultTextStyle>
</p:presentation>`;
  }

  function buildPresentationRelsXml(slidesData) {
    const slideRelsXml = slidesData.map((slide, index) => {
      return `<Relationship Id="rId${index + 2}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide${index + 1}.xml"/>`;
    }).join("");

    const presPropsId = slidesData.length + 2;
    const viewPropsId = slidesData.length + 3;
    const themeId = slidesData.length + 4;
    const tableStylesId = slidesData.length + 5;

    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="slideMasters/slideMaster1.xml"/>
  ${slideRelsXml}
  <Relationship Id="rId${presPropsId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/presProps" Target="presProps.xml"/>
  <Relationship Id="rId${viewPropsId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/viewProps" Target="viewProps.xml"/>
  <Relationship Id="rId${themeId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="theme/theme1.xml"/>
  <Relationship Id="rId${tableStylesId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/tableStyles" Target="tableStyles.xml"/>
</Relationships>`;
  }

  function buildCoreXml(deckTitle) {
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/">
  <dc:title>${xmlEscape(deckTitle || "Presentation")}</dc:title>
</cp:coreProperties>`;
  }

  function buildSlideRelsXml(imageRelations) {
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="${SLIDE_LAYOUT_TARGET}"/>${imageRelations.map(relation => `
  <Relationship Id="${relation.relId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/${relation.mediaName}"/>`).join("")}
</Relationships>`;
  }

  function buildContentTypesXml(slidesData) {
    const layoutOverrides = Object.keys(TEMPLATE_STATIC_FILES)
      .filter(name => /^ppt\/slideLayouts\/slideLayout\d+\.xml$/.test(name))
      .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }))
      .map(name => {
        const partName = `/${name}`;
        return `<Override PartName="${partName}" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/>`;
      }).join("\n  ");

    const slideOverrides = slidesData.map((slide, index) => {
      return `<Override PartName="/ppt/slides/slide${index + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>`;
    }).join("\n  ");

    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Default Extension="png" ContentType="image/png"/>
  <Default Extension="jpg" ContentType="image/jpeg"/>
  <Default Extension="jpeg" ContentType="image/jpeg"/>
  <Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>
  <Override PartName="/ppt/presProps.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presProps+xml"/>
  <Override PartName="/ppt/viewProps.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.viewProps+xml"/>
  <Override PartName="/ppt/tableStyles.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.tableStyles+xml"/>
  <Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/>
  <Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>
  ${layoutOverrides}
  ${slideOverrides}
  <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
  <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
</Types>`;
  }

  function buildPptx(slidesData, deckTitle) {
    const preparedSlides = slidesData.map(slide => ({
      layout: slide.layout,
      items: slide.items.map(item => ({ ...item })),
      imageRelations: []
    }));

    let mediaIndex = 1;
    preparedSlides.forEach(slide => {
      slide.items.forEach(item => {
        if (item.type !== "image") {
          return;
        }

        const extension = IMAGE_MIME_TO_EXTENSION[item.mimeType] || "png";
        slide.imageRelations.push({
          itemId: item.id,
          relId: `rId${slide.imageRelations.length + 2}`,
          mediaName: `image${mediaIndex++}.${extension}`,
          mimeType: item.mimeType || "image/png",
          data: dataUrlToBytes(item.src)
        });
      });
    });

    const files = [
      { name: "[Content_Types].xml", data: buildContentTypesXml(preparedSlides) },
      { name: "docProps/core.xml", data: buildCoreXml(deckTitle) },
      { name: "ppt/presentation.xml", data: buildPresentationXml(preparedSlides) },
      { name: "ppt/_rels/presentation.xml.rels", data: buildPresentationRelsXml(preparedSlides) }
    ];

    Object.entries(TEMPLATE_STATIC_FILES).forEach(([name, data]) => {
      files.push({ name, data });
    });

    preparedSlides.forEach((slide, index) => {
      files.push({
        name: `ppt/slides/slide${index + 1}.xml`,
        data: buildSlideXml(slide, slide.imageRelations)
      });
      files.push({
        name: `ppt/slides/_rels/slide${index + 1}.xml.rels`,
        data: buildSlideRelsXml(slide.imageRelations)
      });

      slide.imageRelations.forEach(relation => {
        files.push({
          name: `ppt/media/${relation.mediaName}`,
          data: relation.data
        });
      });
    });

    return createZip(files);
  }

  window.buildTextParagraphsXml = buildTextParagraphsXml;
  window.buildPresentationXml = buildPresentationXml;
  window.buildPresentationRelsXml = buildPresentationRelsXml;
  window.buildPptx = buildPptx;
})();
