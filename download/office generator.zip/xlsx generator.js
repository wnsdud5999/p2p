const encoder = new TextEncoder();
const sheetGrid = document.getElementById("sheetGrid");
const formulaInput = document.getElementById("formulaInput");
const selectedCellBox = document.getElementById("selectedCellBox");
const fileNameInput = document.getElementById("fileNameInput");
const sheetNameInput = document.getElementById("sheetNameInput");
const downloadBtn = document.getElementById("downloadBtn");
const sheetStatus = document.getElementById("sheetStatus");
const addRowBtn = document.getElementById("addRowBtn");
const removeRowBtn = document.getElementById("removeRowBtn");
const addColBtn = document.getElementById("addColBtn");
const removeColBtn = document.getElementById("removeColBtn");
const clearSheetBtn = document.getElementById("clearSheetBtn");
const resetSheetBtn = document.getElementById("resetSheetBtn");
const newSheetBtn = document.getElementById("newSheetBtn");
const deleteSheetBtn = document.getElementById("deleteSheetBtn");
const cellEditor = document.getElementById("cellEditor");
const sheetTabs = document.getElementById("sheetTabs");
const addSheetBtn = document.getElementById("addSheetBtn");
const sheetShell = document.querySelector(".sheet-shell");
const sheetStage = document.querySelector(".sheet-stage");
const menuTabs = Array.from(document.querySelectorAll(".menu-tab"));
const toolPanels = Array.from(document.querySelectorAll(".tool-panel"));

const DEFAULT_ROWS = 30;
const DEFAULT_COLS = 12;
const DEFAULT_COL_WIDTH = 116;
const MIN_COL_WIDTH = 72;

let nextSheetId = 1;
let workbookSheets = [createSheet("Sheet1")];
let activeSheetIndex = 0;
let activeCell = { row: 0, col: 0 };
let selectionAnchor = { row: 0, col: 0 };
let isEditingCell = false;
let columnResizeState = null;
let selectionDragState = null;
let fillDragState = null;
let fillPreviewRange = null;
let lastSavedWorkbookSignature = "";

function createMatrix(rows, cols) {
  return Array.from({ length: rows }, () => Array.from({ length: cols }, () => ""));
}

function createSheet(name, rows = DEFAULT_ROWS, cols = DEFAULT_COLS) {
  return {
    id: `sheet-${nextSheetId++}`,
    name: normalizeSheetName(name),
    data: createMatrix(rows, cols),
    columnWidths: Array.from({ length: cols }, () => DEFAULT_COL_WIDTH)
  };
}

function getActiveSheet() {
  return workbookSheets[activeSheetIndex];
}

function getRowCount(sheet = getActiveSheet()) {
  return sheet.data.length;
}

function getColCount(sheet = getActiveSheet()) {
  return sheet.data[0]?.length || 0;
}

function getCellValue(row = activeCell.row, col = activeCell.col) {
  return getActiveSheet().data[row]?.[col] || "";
}

function getWorkbookSnapshot() {
  const snapshotSheets = workbookSheets.map((sheet, index) => {
    const data = sheet.data.map(row => [...row]);
    const columnWidths = [...sheet.columnWidths];

    if (index === activeSheetIndex && isEditingCell && data[activeCell.row]?.[activeCell.col] !== undefined) {
      data[activeCell.row][activeCell.col] = cellEditor.value;
    }

    return {
      name: sheet.name,
      data,
      columnWidths
    };
  });

  return JSON.stringify({
    fileName: normalizeFileBaseName(fileNameInput.value.trim()),
    sheetNameDraft: sheetNameInput.value.trim(),
    sheets: snapshotSheets
  });
}

function markWorkbookAsSaved() {
  lastSavedWorkbookSignature = getWorkbookSnapshot();
}

function hasUnsavedWorkbookChanges() {
  return getWorkbookSnapshot() !== lastSavedWorkbookSignature;
}

window.addEventListener("beforeunload", event => {
  if (!hasUnsavedWorkbookChanges()) {
    return;
  }

  event.preventDefault();
  event.returnValue = "";
});

function setActiveToolPanel(panelId) {
  toolPanels.forEach(panel => {
    panel.classList.toggle("is-active", panel.id === panelId);
  });

  menuTabs.forEach(tab => {
    const isActive = tab.dataset.panel === panelId;
    tab.classList.toggle("is-active", isActive);
    tab.setAttribute("aria-pressed", isActive ? "true" : "false");
  });
}

function colToName(n) {
  let value = n;
  let output = "";
  while (value > 0) {
    const mod = (value - 1) % 26;
    output = String.fromCharCode(65 + mod) + output;
    value = Math.floor((value - mod) / 26);
  }
  return output;
}

function getCellAddress(row, col) {
  return `${colToName(col + 1)}${row + 1}`;
}

function normalizeFileBaseName(name) {
  return (name || "")
    .replace(/[<>:"/\\|?*\u0000-\u001F]/g, " ")
    .replace(/\s+/g, " ")
    .replace(/\.xlsx$/i, "")
    .trim();
}

function normalizeSheetName(name) {
  const cleaned = (name || "")
    .replace(/[\[\]\*\/\\\?:]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  return (cleaned || "Sheet1").slice(0, 31);
}

function ensureUniqueSheetName(name, excludeIndex = -1) {
  const normalized = normalizeSheetName(name);
  let candidate = normalized;
  let counter = 2;

  while (workbookSheets.some((sheet, index) => index !== excludeIndex && sheet.name.toLowerCase() === candidate.toLowerCase())) {
    const suffix = ` ${counter}`;
    candidate = `${normalized.slice(0, Math.max(1, 31 - suffix.length))}${suffix}`;
    counter += 1;
  }

  return candidate;
}

function clampRow(row, sheet = getActiveSheet()) {
  return Math.max(0, Math.min(row, Math.max(0, getRowCount(sheet) - 1)));
}

function clampCol(col, sheet = getActiveSheet()) {
  return Math.max(0, Math.min(col, Math.max(0, getColCount(sheet) - 1)));
}

function normalizeRange(start, end) {
  return {
    startRow: Math.min(start.row, end.row),
    endRow: Math.max(start.row, end.row),
    startCol: Math.min(start.col, end.col),
    endCol: Math.max(start.col, end.col)
  };
}

function getSelectionRange() {
  return normalizeRange(selectionAnchor, activeCell);
}

function isSingleCellSelection(range = getSelectionRange()) {
  return range.startRow === range.endRow && range.startCol === range.endCol;
}

function rangeContainsCell(range, row, col) {
  return row >= range.startRow && row <= range.endRow && col >= range.startCol && col <= range.endCol;
}

function getSelectionAddress(range = getSelectionRange()) {
  if (isSingleCellSelection(range)) {
    return getCellAddress(range.startRow, range.startCol);
  }

  return `${getCellAddress(range.startRow, range.startCol)}:${getCellAddress(range.endRow, range.endCol)}`;
}

function getPrimarySelectionCell(range = getSelectionRange()) {
  if (isSingleCellSelection(range)) {
    return { row: activeCell.row, col: activeCell.col };
  }

  return { row: range.startRow, col: range.startCol };
}

function syncSheetNameField() {
  sheetNameInput.value = getActiveSheet().name;
}

function updateSheetStatus() {
  const sheet = getActiveSheet();
  const range = getSelectionRange();
  const selectedRows = range.endRow - range.startRow + 1;
  const selectedCols = range.endCol - range.startCol + 1;
  const selectionLabel = isSingleCellSelection(range) ? getSelectionAddress(range) : `${selectedRows} x ${selectedCols} selected`;
  sheetStatus.textContent = `${sheet.name} | ${getRowCount(sheet)} rows x ${getColCount(sheet)} columns | ${selectionLabel}`;
  deleteSheetBtn.disabled = workbookSheets.length <= 1;
}

function ensureSelectionInBounds() {
  activeCell = {
    row: clampRow(activeCell.row),
    col: clampCol(activeCell.col)
  };
  selectionAnchor = {
    row: clampRow(selectionAnchor.row),
    col: clampCol(selectionAnchor.col)
  };
}

function ensureSheetSize(minRows, minCols, sheet = getActiveSheet()) {
  const targetRows = Math.max(1, minRows);
  const targetCols = Math.max(1, minCols);
  const currentCols = Math.max(1, getColCount(sheet));

  while (sheet.data.length < targetRows) {
    sheet.data.push(Array.from({ length: currentCols }, () => ""));
  }

  if (getColCount(sheet) < targetCols) {
    const colsToAdd = targetCols - getColCount(sheet);
    sheet.data.forEach(row => {
      for (let index = 0; index < colsToAdd; index++) {
        row.push("");
      }
    });
    for (let index = 0; index < colsToAdd; index++) {
      sheet.columnWidths.push(DEFAULT_COL_WIDTH);
    }
  }
}

function getCellElement(row = activeCell.row, col = activeCell.col) {
  return sheetGrid.querySelector(`.sheet-cell[data-row="${row}"][data-col="${col}"]`);
}

function getCellElementFromPoint(clientX, clientY) {
  const pointed = document.elementFromPoint(clientX, clientY);
  return pointed ? pointed.closest(".sheet-cell") : null;
}

function focusActiveCell(scrollIntoView = true) {
  const cell = getCellElement();
  if (!cell) {
    return;
  }

  cell.focus({ preventScroll: !scrollIntoView });
  if (scrollIntoView) {
    cell.scrollIntoView({ block: "nearest", inline: "nearest" });
  }
}

function positionCellEditor() {
  if (!isEditingCell || cellEditor.hidden) {
    return;
  }

  const cell = getCellElement();
  if (!cell) {
    return;
  }

  const stageRect = sheetStage.getBoundingClientRect();
  const cellRect = cell.getBoundingClientRect();
  cellEditor.style.left = `${cellRect.left - stageRect.left - 1}px`;
  cellEditor.style.top = `${cellRect.top - stageRect.top - 1}px`;
  cellEditor.style.width = `${cellRect.width + 2}px`;
  cellEditor.style.height = `${cellRect.height + 2}px`;
}

function applyFillHandle(range) {
  const handleCell = getCellElement(range.endRow, range.endCol);
  if (!handleCell) {
    return;
  }

  const handle = document.createElement("button");
  handle.type = "button";
  handle.className = "selection-fill-handle";
  handle.tabIndex = -1;
  handle.setAttribute("aria-label", "Drag to copy selected cells");
  handleCell.appendChild(handle);
}

function refreshSelection() {
  sheetGrid.querySelectorAll(".sheet-cell.is-active, .sheet-cell.is-range-selected, .sheet-cell.is-fill-preview, thead th.is-active, thead th.is-selected, tbody th.is-active, tbody th.is-selected").forEach(node => {
    node.classList.remove("is-active", "is-range-selected", "is-fill-preview", "is-selected");
  });
  sheetGrid.querySelectorAll(".selection-fill-handle").forEach(node => node.remove());

  const range = getSelectionRange();

  for (let row = range.startRow; row <= range.endRow; row++) {
    const rowHeader = sheetGrid.querySelector(`tbody th[data-row="${row}"]`);
    if (rowHeader) {
      rowHeader.classList.add("is-selected");
    }

    for (let col = range.startCol; col <= range.endCol; col++) {
      const selectedCell = getCellElement(row, col);
      if (selectedCell) {
        selectedCell.classList.add("is-range-selected");
      }
    }
  }

  for (let col = range.startCol; col <= range.endCol; col++) {
    const selectedHeader = sheetGrid.querySelector(`thead th[data-col="${col}"]`);
    if (selectedHeader) {
      selectedHeader.classList.add("is-selected");
    }
  }

  if (fillPreviewRange) {
    for (let row = fillPreviewRange.startRow; row <= fillPreviewRange.endRow; row++) {
      for (let col = fillPreviewRange.startCol; col <= fillPreviewRange.endCol; col++) {
        if (rangeContainsCell(range, row, col)) {
          continue;
        }

        const previewCell = getCellElement(row, col);
        if (previewCell) {
          previewCell.classList.add("is-fill-preview");
        }
      }
    }
  }

  const cell = getCellElement();
  if (cell) {
    cell.classList.add("is-active");
  }

  const colHeader = sheetGrid.querySelector(`thead th[data-col="${activeCell.col}"]`);
  if (colHeader) {
    colHeader.classList.add("is-active");
  }

  const rowHeader = sheetGrid.querySelector(`tbody th[data-row="${activeCell.row}"]`);
  if (rowHeader) {
    rowHeader.classList.add("is-active");
  }

  applyFillHandle(range);
  selectedCellBox.textContent = getSelectionAddress(range);
  if (!isEditingCell) {
    const previewCell = getPrimarySelectionCell(range);
    formulaInput.value = getCellValue(previewCell.row, previewCell.col);
  }
  updateSheetStatus();
  positionCellEditor();
}

function setSelection(anchorRow, anchorCol, focusRow, focusCol, options = {}) {
  const { focus = false, scrollIntoView = true } = options;
  const sheet = getActiveSheet();

  selectionAnchor = {
    row: clampRow(anchorRow, sheet),
    col: clampCol(anchorCol, sheet)
  };
  activeCell = {
    row: clampRow(focusRow, sheet),
    col: clampCol(focusCol, sheet)
  };

  fillPreviewRange = null;
  refreshSelection();

  if (focus) {
    requestAnimationFrame(() => focusActiveCell(scrollIntoView));
  }
}

function setActiveCell(row, col, options = {}) {
  setSelection(row, col, row, col, options);
}

function moveSelection(rowDelta, colDelta, options = {}) {
  if (isEditingCell) {
    return;
  }

  const { extend = false } = options;
  if (extend) {
    setSelection(selectionAnchor.row, selectionAnchor.col, activeCell.row + rowDelta, activeCell.col + colDelta, { focus: true });
    return;
  }

  setActiveCell(activeCell.row + rowDelta, activeCell.col + colDelta, { focus: true });
}

function updateCellDisplay(row, col, value) {
  const display = sheetGrid.querySelector(`.sheet-cell[data-row="${row}"][data-col="${col}"] .sheet-cell-display`);
  if (display) {
    display.textContent = value;
  }
}

function updateCellValue(row, col, value) {
  const sheet = getActiveSheet();
  if (!sheet.data[row] || typeof sheet.data[row][col] === "undefined") {
    return;
  }

  sheet.data[row][col] = value;
  updateCellDisplay(row, col, value);

  if (!isEditingCell) {
    const previewCell = getPrimarySelectionCell();
    formulaInput.value = getCellValue(previewCell.row, previewCell.col);
  }
}

function getRangeMatrix(range, sheet = getActiveSheet()) {
  const matrix = [];

  for (let row = range.startRow; row <= range.endRow; row++) {
    const rowValues = [];
    for (let col = range.startCol; col <= range.endCol; col++) {
      rowValues.push(sheet.data[row]?.[col] || "");
    }
    matrix.push(rowValues);
  }

  return matrix;
}

function clearRange(range) {
  const sheet = getActiveSheet();

  for (let row = range.startRow; row <= range.endRow; row++) {
    for (let col = range.startCol; col <= range.endCol; col++) {
      sheet.data[row][col] = "";
      updateCellDisplay(row, col, "");
    }
  }
}

function matrixToClipboardText(matrix) {
  return matrix.map(row => row.join("\t")).join("\r\n");
}

function parseClipboardTable(text) {
  const normalized = String(text ?? "").replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const rows = normalized.split("\n");

  while (rows.length > 1 && rows[rows.length - 1] === "") {
    rows.pop();
  }

  return rows.map(row => row.split("\t"));
}

function isInputLikeElement(element) {
  return Boolean(element && element.closest("input, textarea"));
}

function isGridFocused(event) {
  const activeElement = document.activeElement;
  const target = event?.target instanceof Element ? event.target : null;

  return Boolean(
    (activeElement && sheetGrid.contains(activeElement)) ||
    (target && target.closest("#sheetGrid")) ||
    selectionDragState ||
    fillDragState
  );
}

function shouldHandleGridClipboard(event) {
  const activeElement = document.activeElement;
  const target = event?.target instanceof Element ? event.target : null;

  if (isEditingCell || activeElement === formulaInput || activeElement === fileNameInput || activeElement === sheetNameInput) {
    return false;
  }

  if (isInputLikeElement(target) && !target.closest("#sheetGrid")) {
    return false;
  }

  return isGridFocused(event);
}

function applyMatrixToSheet(startRow, startCol, matrix) {
  const rowCount = matrix.length;
  const colCount = Math.max(...matrix.map(row => row.length), 1);
  const sheet = getActiveSheet();
  ensureSheetSize(startRow + rowCount, startCol + colCount, sheet);

  for (let rowOffset = 0; rowOffset < rowCount; rowOffset++) {
    for (let colOffset = 0; colOffset < colCount; colOffset++) {
      sheet.data[startRow + rowOffset][startCol + colOffset] = matrix[rowOffset][colOffset] ?? "";
    }
  }

  selectionAnchor = { row: startRow + rowCount - 1, col: startCol + colCount - 1 };
  activeCell = { row: startRow, col: startCol };
  fillPreviewRange = null;
  renderGrid();
  requestAnimationFrame(() => focusActiveCell(true));
}

function positiveModulo(value, divisor) {
  return ((value % divisor) + divisor) % divisor;
}

function getFillPreview(sourceRange, row, col) {
  if (rangeContainsCell(sourceRange, row, col)) {
    return null;
  }

  const extendUp = row < sourceRange.startRow ? sourceRange.startRow - row : 0;
  const extendDown = row > sourceRange.endRow ? row - sourceRange.endRow : 0;
  const extendLeft = col < sourceRange.startCol ? sourceRange.startCol - col : 0;
  const extendRight = col > sourceRange.endCol ? col - sourceRange.endCol : 0;
  const verticalDistance = Math.max(extendUp, extendDown);
  const horizontalDistance = Math.max(extendLeft, extendRight);

  if (!verticalDistance && !horizontalDistance) {
    return null;
  }

  if (verticalDistance >= horizontalDistance) {
    return {
      startRow: row < sourceRange.startRow ? row : sourceRange.startRow,
      endRow: row > sourceRange.endRow ? row : sourceRange.endRow,
      startCol: sourceRange.startCol,
      endCol: sourceRange.endCol
    };
  }

  return {
    startRow: sourceRange.startRow,
    endRow: sourceRange.endRow,
    startCol: col < sourceRange.startCol ? col : sourceRange.startCol,
    endCol: col > sourceRange.endCol ? col : sourceRange.endCol
  };
}

function applyFillDrag(sourceRange, fillRange, sourceMatrix) {
  if (!fillRange) {
    return;
  }

  const sheet = getActiveSheet();
  ensureSheetSize(fillRange.endRow + 1, fillRange.endCol + 1, sheet);
  const sourceHeight = sourceMatrix.length;
  const sourceWidth = sourceMatrix[0]?.length || 1;

  for (let row = fillRange.startRow; row <= fillRange.endRow; row++) {
    for (let col = fillRange.startCol; col <= fillRange.endCol; col++) {
      if (rangeContainsCell(sourceRange, row, col)) {
        continue;
      }

      const sourceRow = positiveModulo(row - sourceRange.startRow, sourceHeight);
      const sourceCol = positiveModulo(col - sourceRange.startCol, sourceWidth);
      sheet.data[row][col] = sourceMatrix[sourceRow][sourceCol];
    }
  }

  selectionAnchor = { row: fillRange.endRow, col: fillRange.endCol };
  activeCell = { row: fillRange.startRow, col: fillRange.startCol };
  fillPreviewRange = null;
  renderGrid();
  requestAnimationFrame(() => focusActiveCell(true));
}

function startCellEdit(options = {}) {
  const {
    value = getCellValue(),
    selectAll = false,
    caretAtEnd = true
  } = options;

  if (!isSingleCellSelection()) {
    setActiveCell(activeCell.row, activeCell.col, { focus: false });
  }

  const cell = getCellElement();
  if (!cell) {
    return;
  }

  isEditingCell = true;
  cellEditor.hidden = false;
  cellEditor.value = value;
  formulaInput.value = value;
  positionCellEditor();

  requestAnimationFrame(() => {
    cellEditor.focus();
    if (selectAll) {
      cellEditor.select();
      return;
    }

    const caretPosition = caretAtEnd ? cellEditor.value.length : 0;
    cellEditor.setSelectionRange(caretPosition, caretPosition);
  });
}

function commitCellEdit(options = {}) {
  if (!isEditingCell) {
    return;
  }

  const { rowDelta = 0, colDelta = 0, focus = true } = options;
  const nextValue = cellEditor.value;
  isEditingCell = false;
  cellEditor.hidden = true;
  updateCellValue(activeCell.row, activeCell.col, nextValue);

  if (rowDelta || colDelta) {
    setActiveCell(activeCell.row + rowDelta, activeCell.col + colDelta, { focus });
  } else {
    refreshSelection();
    if (focus) {
      requestAnimationFrame(() => focusActiveCell(true));
    }
  }
}

function cancelCellEdit() {
  if (!isEditingCell) {
    return;
  }

  isEditingCell = false;
  cellEditor.hidden = true;
  formulaInput.value = getCellValue();
  refreshSelection();
  requestAnimationFrame(() => focusActiveCell(true));
}

function renderSheetTabs() {
  sheetTabs.innerHTML = "";

  workbookSheets.forEach((sheet, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = `sheet-tab${index === activeSheetIndex ? " is-active" : ""}`;
    button.dataset.index = String(index);
    button.textContent = sheet.name;
    sheetTabs.appendChild(button);
  });

  syncSheetNameField();
  updateSheetStatus();
}

function renderGrid() {
  ensureSelectionInBounds();
  const range = getSelectionRange();
  const sheet = getActiveSheet();
  const rowCount = getRowCount(sheet);
  const colCount = getColCount(sheet);
  const fragment = document.createDocumentFragment();
  const colGroup = document.createElement("colgroup");
  const rowHeaderCol = document.createElement("col");
  rowHeaderCol.style.width = "48px";
  colGroup.appendChild(rowHeaderCol);

  for (let col = 0; col < colCount; col++) {
    const colElement = document.createElement("col");
    colElement.style.width = `${sheet.columnWidths[col] || DEFAULT_COL_WIDTH}px`;
    colGroup.appendChild(colElement);
  }

  fragment.appendChild(colGroup);

  const thead = document.createElement("thead");
  const headRow = document.createElement("tr");
  const corner = document.createElement("th");
  corner.className = "corner";
  headRow.appendChild(corner);

  for (let col = 0; col < colCount; col++) {
    const th = document.createElement("th");
    const isSelected = col >= range.startCol && col <= range.endCol;
    const isActive = col === activeCell.col;
    th.className = `col-header${isSelected ? " is-selected" : ""}${isActive ? " is-active" : ""}`;
    th.dataset.col = String(col);

    const label = document.createElement("span");
    label.className = "col-header-label";
    label.textContent = colToName(col + 1);

    const handle = document.createElement("button");
    handle.type = "button";
    handle.className = "col-resize-handle";
    handle.dataset.col = String(col);
    handle.tabIndex = -1;
    handle.setAttribute("aria-label", `Resize column ${colToName(col + 1)}`);

    th.append(label, handle);
    headRow.appendChild(th);
  }

  thead.appendChild(headRow);
  fragment.appendChild(thead);

  const tbody = document.createElement("tbody");
  for (let row = 0; row < rowCount; row++) {
    const tr = document.createElement("tr");
    const rowHeader = document.createElement("th");
    rowHeader.dataset.row = String(row);
    rowHeader.textContent = String(row + 1);
    if (row >= range.startRow && row <= range.endRow) {
      rowHeader.classList.add("is-selected");
    }
    if (row === activeCell.row) {
      rowHeader.classList.add("is-active");
    }
    tr.appendChild(rowHeader);

    for (let col = 0; col < colCount; col++) {
      const td = document.createElement("td");
      const isSelected = rangeContainsCell(range, row, col);
      const isActive = row === activeCell.row && col === activeCell.col;
      td.className = `sheet-cell${isSelected ? " is-range-selected" : ""}${isActive ? " is-active" : ""}`;
      td.dataset.row = String(row);
      td.dataset.col = String(col);
      td.tabIndex = -1;

      const display = document.createElement("div");
      display.className = "sheet-cell-display";
      display.textContent = sheet.data[row][col];
      td.appendChild(display);
      tr.appendChild(td);
    }

    tbody.appendChild(tr);
  }

  fragment.appendChild(tbody);
  sheetGrid.innerHTML = "";
  sheetGrid.appendChild(fragment);
  renderSheetTabs();
  refreshSelection();
}

function addSheet() {
  if (isEditingCell) {
    commitCellEdit({ focus: false });
  }

  const defaultName = ensureUniqueSheetName(`Sheet${workbookSheets.length + 1}`);
  workbookSheets.push(createSheet(defaultName));
  activeSheetIndex = workbookSheets.length - 1;
  activeCell = { row: 0, col: 0 };
  selectionAnchor = { row: 0, col: 0 };
  fillPreviewRange = null;
  renderGrid();
  requestAnimationFrame(() => focusActiveCell(true));
}

function deleteActiveSheet() {
  if (workbookSheets.length <= 1) {
    return;
  }

  workbookSheets.splice(activeSheetIndex, 1);
  activeSheetIndex = Math.max(0, Math.min(activeSheetIndex, workbookSheets.length - 1));
  activeCell = { row: 0, col: 0 };
  selectionAnchor = { row: 0, col: 0 };
  fillPreviewRange = null;
  renderGrid();
  requestAnimationFrame(() => focusActiveCell(true));
}

function applySheetName(name) {
  const activeSheet = getActiveSheet();
  activeSheet.name = ensureUniqueSheetName(name, activeSheetIndex);
  syncSheetNameField();
  renderSheetTabs();
}

function pxToExcelWidth(px) {
  return Math.round((Math.max(MIN_COL_WIDTH, px) - 5) / 7 * 100) / 100;
}

function xmlEscape(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function inlineStringXml(value) {
  const preserve = /^\s|\s$| {2,}/.test(value);
  return `<is><t${preserve ? ' xml:space="preserve"' : ""}>${xmlEscape(value)}</t></is>`;
}

function buildCellXml(value, rowIndex, colIndex) {
  const text = String(value ?? "");
  const trimmed = text.trim();
  if (!trimmed) {
    return "";
  }

  const ref = `${colToName(colIndex + 1)}${rowIndex + 1}`;
  if (trimmed.startsWith("=") && trimmed.length > 1) {
    return `<c r="${ref}"><f>${xmlEscape(trimmed.slice(1))}</f></c>`;
  }

  if (/^-?(?:\d+|\d*\.\d+)$/.test(trimmed)) {
    return `<c r="${ref}"><v>${trimmed}</v></c>`;
  }

  return `<c r="${ref}" t="inlineStr">${inlineStringXml(text)}</c>`;
}

function buildWorksheetXml(sheet) {
  const rowCount = Math.max(1, getRowCount(sheet));
  const colCount = Math.max(1, getColCount(sheet));
  const colsXml = sheet.columnWidths
    .slice(0, colCount)
    .map((width, index) => `<col min="${index + 1}" max="${index + 1}" width="${pxToExcelWidth(width)}" customWidth="1"/>`)
    .join("");
  const rowsXml = sheet.data.map((row, rowIndex) => {
    const cellsXml = row
      .map((value, colIndex) => buildCellXml(value, rowIndex, colIndex))
      .filter(Boolean)
      .join("");
    return cellsXml ? `<row r="${rowIndex + 1}">${cellsXml}</row>` : `<row r="${rowIndex + 1}"/>`;
  }).join("");
  const lastCell = `${colToName(colCount)}${rowCount}`;

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <dimension ref="A1:${lastCell}"/>
  <sheetViews>
    <sheetView workbookViewId="0"/>
  </sheetViews>
  <sheetFormatPr defaultRowHeight="15"/>
  <cols>${colsXml}</cols>
  <sheetData>${rowsXml}</sheetData>
</worksheet>`;
}

function buildXlsx(sheets, workbookTitle) {
  const sheetOverrides = sheets
    .map((sheet, index) => `<Override PartName="/xl/worksheets/sheet${index + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`)
    .join("\n  ");
  const workbookSheetsXml = sheets
    .map((sheet, index) => `<sheet name="${xmlEscape(sheet.name)}" sheetId="${index + 1}" r:id="rId${index + 1}"/>`)
    .join("\n    ");
  const workbookRelsXml = sheets
    .map((sheet, index) => `<Relationship Id="rId${index + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${index + 1}.xml"/>`)
    .join("\n  ");
  const files = [
    {
      name: "[Content_Types].xml",
      data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  ${sheetOverrides}
  <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
  <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
</Types>`
    },
    {
      name: "_rels/.rels",
      data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>`
    },
    {
      name: "docProps/core.xml",
      data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/">
  <dc:title>${xmlEscape(workbookTitle || "Workbook")}</dc:title>
</cp:coreProperties>`
    },
    {
      name: "docProps/app.xml",
      data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
  <Application>Browser XLSX Generator</Application>
</Properties>`
    },
    {
      name: "xl/workbook.xml",
      data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <bookViews>
    <workbookView activeTab="${activeSheetIndex}"/>
  </bookViews>
  <sheets>
    ${workbookSheetsXml}
  </sheets>
  <calcPr calcId="0" fullCalcOnLoad="1"/>
</workbook>`
    },
    {
      name: "xl/_rels/workbook.xml.rels",
      data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  ${workbookRelsXml}
</Relationships>`
    }
  ];

  sheets.forEach((sheet, index) => {
    files.push({
      name: `xl/worksheets/sheet${index + 1}.xml`,
      data: buildWorksheetXml(sheet)
    });
  });

  return createZip(files);
}

function toBytes(data) {
  return data instanceof Uint8Array ? data : encoder.encode(data);
}

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let j = 0; j < 8; j++) {
      c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    }
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(bytes) {
  let crc = 0xFFFFFFFF;
  for (let i = 0; i < bytes.length; i++) {
    crc = CRC_TABLE[(crc ^ bytes[i]) & 0xFF] ^ (crc >>> 8);
  }
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

function dosDateTime(date = new Date()) {
  const year = Math.max(1980, date.getFullYear());
  const month = date.getMonth() + 1;
  const day = date.getDate();
  const hours = date.getHours();
  const minutes = date.getMinutes();
  const seconds = Math.floor(date.getSeconds() / 2);
  return {
    dosTime: (hours << 11) | (minutes << 5) | seconds,
    dosDate: ((year - 1980) << 9) | (month << 5) | day
  };
}

function writeUInt16LE(view, offset, value) {
  view.setUint16(offset, value, true);
}

function writeUInt32LE(view, offset, value) {
  view.setUint32(offset, value >>> 0, true);
}

function createZip(files) {
  const now = dosDateTime();
  const localParts = [];
  const centralParts = [];
  let offset = 0;

  files.forEach(file => {
    const nameBytes = toBytes(file.name);
    const dataBytes = toBytes(file.data);
    const crc = crc32(dataBytes);

    const localHeader = new ArrayBuffer(30);
    const lv = new DataView(localHeader);
    writeUInt32LE(lv, 0, 0x04034b50);
    writeUInt16LE(lv, 4, 20);
    writeUInt16LE(lv, 6, 0);
    writeUInt16LE(lv, 8, 0);
    writeUInt16LE(lv, 10, now.dosTime);
    writeUInt16LE(lv, 12, now.dosDate);
    writeUInt32LE(lv, 14, crc);
    writeUInt32LE(lv, 18, dataBytes.length);
    writeUInt32LE(lv, 22, dataBytes.length);
    writeUInt16LE(lv, 26, nameBytes.length);
    writeUInt16LE(lv, 28, 0);

    localParts.push(new Uint8Array(localHeader), nameBytes, dataBytes);

    const centralHeader = new ArrayBuffer(46);
    const cv = new DataView(centralHeader);
    writeUInt32LE(cv, 0, 0x02014b50);
    writeUInt16LE(cv, 4, 20);
    writeUInt16LE(cv, 6, 20);
    writeUInt16LE(cv, 8, 0);
    writeUInt16LE(cv, 10, 0);
    writeUInt16LE(cv, 12, now.dosTime);
    writeUInt16LE(cv, 14, now.dosDate);
    writeUInt32LE(cv, 16, crc);
    writeUInt32LE(cv, 20, dataBytes.length);
    writeUInt32LE(cv, 24, dataBytes.length);
    writeUInt16LE(cv, 28, nameBytes.length);
    writeUInt16LE(cv, 30, 0);
    writeUInt16LE(cv, 32, 0);
    writeUInt16LE(cv, 34, 0);
    writeUInt16LE(cv, 36, 0);
    writeUInt32LE(cv, 38, 0);
    writeUInt32LE(cv, 42, offset);

    centralParts.push(new Uint8Array(centralHeader), nameBytes);
    offset += 30 + nameBytes.length + dataBytes.length;
  });

  const centralSize = centralParts.reduce((sum, part) => sum + part.length, 0);
  const eocd = new ArrayBuffer(22);
  const ev = new DataView(eocd);
  writeUInt32LE(ev, 0, 0x06054b50);
  writeUInt16LE(ev, 4, 0);
  writeUInt16LE(ev, 6, 0);
  writeUInt16LE(ev, 8, files.length);
  writeUInt16LE(ev, 10, files.length);
  writeUInt32LE(ev, 12, centralSize);
  writeUInt32LE(ev, 16, offset);
  writeUInt16LE(ev, 20, 0);

  return new Blob([...localParts, ...centralParts, new Uint8Array(eocd)], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
  });
}

function triggerDownload(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

menuTabs.forEach(tab => {
  tab.addEventListener("click", () => {
    setActiveToolPanel(tab.dataset.panel);
  });
});

sheetGrid.addEventListener("mousedown", event => {
  if (event.button !== 0) {
    return;
  }

  const resizeHandle = event.target.closest(".col-resize-handle");
  if (resizeHandle) {
    event.preventDefault();
    if (isEditingCell) {
      commitCellEdit({ focus: false });
    }

    const col = Number.parseInt(resizeHandle.dataset.col || "0", 10);
    columnResizeState = {
      col,
      startX: event.clientX,
      startWidth: getActiveSheet().columnWidths[col] || DEFAULT_COL_WIDTH
    };
    sheetShell.classList.add("is-resizing-column");
    return;
  }

  const fillHandle = event.target.closest(".selection-fill-handle");
  if (fillHandle) {
    event.preventDefault();
    event.stopPropagation();
    if (isEditingCell) {
      commitCellEdit({ focus: false });
    }

    fillDragState = {
      sourceRange: getSelectionRange(),
      sourceMatrix: getRangeMatrix(getSelectionRange())
    };
    return;
  }

  const cell = event.target.closest(".sheet-cell");
  if (!cell) {
    return;
  }

  event.preventDefault();
  if (isEditingCell) {
    commitCellEdit({ focus: false });
  }

  const row = Number.parseInt(cell.dataset.row || "0", 10);
  const col = Number.parseInt(cell.dataset.col || "0", 10);
  const anchor = event.shiftKey ? { ...selectionAnchor } : { row, col };
  setSelection(anchor.row, anchor.col, row, col, { focus: true, scrollIntoView: false });
  selectionDragState = { anchor };
});

sheetGrid.addEventListener("dblclick", event => {
  const cell = event.target.closest(".sheet-cell");
  if (!cell) {
    return;
  }

  const row = Number.parseInt(cell.dataset.row || "0", 10);
  const col = Number.parseInt(cell.dataset.col || "0", 10);
  setActiveCell(row, col, { focus: false });
  startCellEdit({ value: getCellValue(), caretAtEnd: true });
});

sheetGrid.addEventListener("keydown", event => {
  if (!event.target.closest(".sheet-cell") || isEditingCell) {
    return;
  }

  const commandKey = event.ctrlKey || event.metaKey;
  const isPrintable = event.key.length === 1 && !commandKey && !event.altKey;

  if (commandKey && event.key.toLowerCase() === "a") {
    event.preventDefault();
    setSelection(0, 0, getRowCount() - 1, getColCount() - 1, { focus: true });
    return;
  }

  if (isPrintable) {
    event.preventDefault();
    startCellEdit({ value: event.key, caretAtEnd: true });
    return;
  }

  if (event.key === "F2") {
    event.preventDefault();
    startCellEdit({ value: getCellValue(), caretAtEnd: true });
    return;
  }

  if (event.key === "Delete" || event.key === "Backspace") {
    event.preventDefault();
    clearRange(getSelectionRange());
    refreshSelection();
    return;
  }

  if (event.key === "Tab") {
    event.preventDefault();
    moveSelection(0, event.shiftKey ? -1 : 1);
    return;
  }

  if (event.key === "Enter") {
    event.preventDefault();
    moveSelection(event.shiftKey ? -1 : 1, 0);
    return;
  }

  if (event.key === "ArrowUp") {
    event.preventDefault();
    moveSelection(-1, 0, { extend: event.shiftKey });
    return;
  }

  if (event.key === "ArrowDown") {
    event.preventDefault();
    moveSelection(1, 0, { extend: event.shiftKey });
    return;
  }

  if (event.key === "ArrowLeft") {
    event.preventDefault();
    moveSelection(0, -1, { extend: event.shiftKey });
    return;
  }

  if (event.key === "ArrowRight") {
    event.preventDefault();
    moveSelection(0, 1, { extend: event.shiftKey });
  }
});

document.addEventListener("copy", event => {
  if (!shouldHandleGridClipboard(event)) {
    return;
  }

  event.preventDefault();
  event.clipboardData?.setData("text/plain", matrixToClipboardText(getRangeMatrix(getSelectionRange())));
});

document.addEventListener("cut", event => {
  if (!shouldHandleGridClipboard(event)) {
    return;
  }

  const range = getSelectionRange();
  event.preventDefault();
  event.clipboardData?.setData("text/plain", matrixToClipboardText(getRangeMatrix(range)));
  clearRange(range);
  refreshSelection();
});

document.addEventListener("paste", event => {
  if (!shouldHandleGridClipboard(event)) {
    return;
  }

  const clipboardText = event.clipboardData?.getData("text/plain") || "";
  if (!clipboardText) {
    return;
  }

  event.preventDefault();
  const matrix = parseClipboardTable(clipboardText);
  const target = getSelectionRange();
  applyMatrixToSheet(target.startRow, target.startCol, matrix);
});

cellEditor.addEventListener("input", () => {
  formulaInput.value = cellEditor.value;
});

cellEditor.addEventListener("keydown", event => {
  if (event.key === "Escape") {
    event.preventDefault();
    cancelCellEdit();
    return;
  }

  if (event.key === "Enter") {
    event.preventDefault();
    commitCellEdit({ rowDelta: event.shiftKey ? -1 : 1 });
    return;
  }

  if (event.key === "Tab") {
    event.preventDefault();
    commitCellEdit({ colDelta: event.shiftKey ? -1 : 1 });
  }
});

cellEditor.addEventListener("blur", () => {
  if (isEditingCell) {
    commitCellEdit({ focus: false });
  }
});

formulaInput.addEventListener("input", () => {
  updateCellValue(activeCell.row, activeCell.col, formulaInput.value);
  if (isEditingCell) {
    cellEditor.value = formulaInput.value;
  }
});

formulaInput.addEventListener("keydown", event => {
  if (event.key === "Enter") {
    event.preventDefault();
    if (isEditingCell) {
      commitCellEdit({ focus: true });
    } else {
      focusActiveCell(true);
    }
  }
});

sheetTabs.addEventListener("click", event => {
  const button = event.target.closest(".sheet-tab");
  if (!button) {
    return;
  }

  if (isEditingCell) {
    commitCellEdit({ focus: false });
  }

  activeSheetIndex = Number.parseInt(button.dataset.index || "0", 10);
  activeCell = { row: 0, col: 0 };
  selectionAnchor = { row: 0, col: 0 };
  fillPreviewRange = null;
  renderGrid();
  requestAnimationFrame(() => focusActiveCell(true));
});

sheetNameInput.addEventListener("change", () => {
  applySheetName(sheetNameInput.value);
});

sheetNameInput.addEventListener("blur", () => {
  applySheetName(sheetNameInput.value);
});

addSheetBtn.addEventListener("click", addSheet);
newSheetBtn.addEventListener("click", addSheet);
deleteSheetBtn.addEventListener("click", deleteActiveSheet);

addRowBtn.addEventListener("click", () => {
  if (isEditingCell) {
    commitCellEdit({ focus: false });
  }

  const sheet = getActiveSheet();
  const colCount = getColCount(sheet) || DEFAULT_COLS;
  const range = getSelectionRange();
  sheet.data.splice(range.endRow + 1, 0, Array.from({ length: colCount }, () => ""));
  activeCell = { row: range.endRow + 1, col: range.startCol };
  selectionAnchor = { ...activeCell };
  renderGrid();
  requestAnimationFrame(() => focusActiveCell(true));
});

removeRowBtn.addEventListener("click", () => {
  if (isEditingCell) {
    commitCellEdit({ focus: false });
  }

  const sheet = getActiveSheet();
  const range = getSelectionRange();
  const removeCount = range.endRow - range.startRow + 1;

  if (sheet.data.length <= removeCount) {
    sheet.data = [Array.from({ length: getColCount(sheet) }, () => "")];
  } else {
    sheet.data.splice(range.startRow, removeCount);
  }

  activeCell = {
    row: Math.min(range.startRow, sheet.data.length - 1),
    col: range.startCol
  };
  selectionAnchor = { ...activeCell };
  renderGrid();
  requestAnimationFrame(() => focusActiveCell(true));
});

addColBtn.addEventListener("click", () => {
  if (isEditingCell) {
    commitCellEdit({ focus: false });
  }

  const sheet = getActiveSheet();
  const range = getSelectionRange();
  sheet.data.forEach(row => {
    row.splice(range.endCol + 1, 0, "");
  });
  sheet.columnWidths.splice(range.endCol + 1, 0, DEFAULT_COL_WIDTH);
  activeCell = { row: range.startRow, col: range.endCol + 1 };
  selectionAnchor = { ...activeCell };
  renderGrid();
  requestAnimationFrame(() => focusActiveCell(true));
});

removeColBtn.addEventListener("click", () => {
  if (isEditingCell) {
    commitCellEdit({ focus: false });
  }

  const sheet = getActiveSheet();
  const range = getSelectionRange();
  const colCount = getColCount(sheet);
  const removeCount = range.endCol - range.startCol + 1;

  if (colCount <= removeCount) {
    sheet.data.forEach(row => {
      row.splice(0, row.length, "");
    });
    sheet.columnWidths = [DEFAULT_COL_WIDTH];
  } else {
    sheet.data.forEach(row => {
      row.splice(range.startCol, removeCount);
    });
    sheet.columnWidths.splice(range.startCol, removeCount);
  }

  activeCell = {
    row: range.startRow,
    col: Math.min(range.startCol, getColCount(sheet) - 1)
  };
  selectionAnchor = { ...activeCell };
  renderGrid();
  requestAnimationFrame(() => focusActiveCell(true));
});

clearSheetBtn.addEventListener("click", () => {
  if (isEditingCell) {
    commitCellEdit({ focus: false });
  }

  const sheet = getActiveSheet();
  sheet.data = sheet.data.map(row => row.map(() => ""));
  fillPreviewRange = null;
  renderGrid();
  requestAnimationFrame(() => focusActiveCell(true));
});

resetSheetBtn.addEventListener("click", () => {
  if (isEditingCell) {
    commitCellEdit({ focus: false });
  }

  const sheet = getActiveSheet();
  sheet.data = createMatrix(DEFAULT_ROWS, DEFAULT_COLS);
  sheet.columnWidths = Array.from({ length: DEFAULT_COLS }, () => DEFAULT_COL_WIDTH);
  activeCell = { row: 0, col: 0 };
  selectionAnchor = { row: 0, col: 0 };
  fillPreviewRange = null;
  renderGrid();
  requestAnimationFrame(() => focusActiveCell(true));
});

downloadBtn.addEventListener("click", () => {
  if (isEditingCell) {
    commitCellEdit({ focus: false });
  }

  applySheetName(sheetNameInput.value);
  const requestedName = fileNameInput.value.trim();
  const safeBaseName = normalizeFileBaseName(requestedName) || "workbook";
  fileNameInput.value = safeBaseName;
  const exportSheets = workbookSheets.map(sheet => ({
    ...sheet,
    data: sheet.data.map(row => [...row]),
    columnWidths: [...sheet.columnWidths]
  }));
  const blob = buildXlsx(exportSheets, requestedName || safeBaseName);
  triggerDownload(blob, `${safeBaseName}.xlsx`);
  markWorkbookAsSaved();
});

document.addEventListener("mousemove", event => {
  if (columnResizeState) {
    const activeSheet = getActiveSheet();
    const nextWidth = Math.max(MIN_COL_WIDTH, columnResizeState.startWidth + (event.clientX - columnResizeState.startX));
    activeSheet.columnWidths[columnResizeState.col] = nextWidth;

    const colElement = sheetGrid.querySelectorAll("col")[columnResizeState.col + 1];
    if (colElement) {
      colElement.style.width = `${nextWidth}px`;
    }

    positionCellEditor();
    return;
  }

  if (selectionDragState) {
    const cell = getCellElementFromPoint(event.clientX, event.clientY);
    if (!cell || !sheetGrid.contains(cell)) {
      return;
    }

    const row = Number.parseInt(cell.dataset.row || "0", 10);
    const col = Number.parseInt(cell.dataset.col || "0", 10);
    setSelection(selectionDragState.anchor.row, selectionDragState.anchor.col, row, col, { focus: false });
    return;
  }

  if (fillDragState) {
    const cell = getCellElementFromPoint(event.clientX, event.clientY);
    if (!cell || !sheetGrid.contains(cell)) {
      return;
    }

    const row = Number.parseInt(cell.dataset.row || "0", 10);
    const col = Number.parseInt(cell.dataset.col || "0", 10);
    const nextPreview = getFillPreview(fillDragState.sourceRange, row, col);
    const nextSignature = nextPreview ? JSON.stringify(nextPreview) : "";
    const currentSignature = fillPreviewRange ? JSON.stringify(fillPreviewRange) : "";

    if (nextSignature !== currentSignature) {
      fillPreviewRange = nextPreview;
      refreshSelection();
    }
  }
});

document.addEventListener("mouseup", () => {
  if (columnResizeState) {
    columnResizeState = null;
    sheetShell.classList.remove("is-resizing-column");
    refreshSelection();
  }

  if (selectionDragState) {
    selectionDragState = null;
    requestAnimationFrame(() => focusActiveCell(false));
  }

  if (fillDragState) {
    const preview = fillPreviewRange;
    const sourceRange = fillDragState.sourceRange;
    const sourceMatrix = fillDragState.sourceMatrix;
    fillDragState = null;

    if (preview) {
      applyFillDrag(sourceRange, preview, sourceMatrix);
      return;
    }

    fillPreviewRange = null;
    refreshSelection();
  }
});

sheetShell.addEventListener("scroll", () => {
  positionCellEditor();
});

window.addEventListener("resize", () => {
  positionCellEditor();
});

setActiveToolPanel("homePanel");
renderGrid();
requestAnimationFrame(() => focusActiveCell(true));
markWorkbookAsSaved();
