@echo off
set "FLAG=%~dp0keep-awake-vbs.running"

if not exist "%FLAG%" (
  echo Keep-awake VBS is not marked as running.
  exit /b 1
)

del "%FLAG%" >nul 2>&1
echo Stop signal sent.
echo The hidden script will exit within about 15 seconds.
