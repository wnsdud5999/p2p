param(
  [switch]$SystemOnly,
  [ValidateRange(5, 3600)]
  [int]$RefreshSeconds = 30,
  [ValidateRange(0, 31536000)]
  [int]$DurationSeconds = 0
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$scriptPath = [System.IO.Path]::GetFullPath($MyInvocation.MyCommand.Path)

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public static class PowerKeepAwake
{
    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern uint SetThreadExecutionState(uint esFlags);
}
"@

$ES_CONTINUOUS = [uint32]2147483648
$ES_SYSTEM_REQUIRED = [uint32]0x00000001
$ES_DISPLAY_REQUIRED = [uint32]0x00000002

function Invoke-ExecutionState {
  param(
    [uint32]$Flags
  )

  $previous = [PowerKeepAwake]::SetThreadExecutionState($Flags)
  if ($previous -eq 0) {
    $lastError = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
    throw "SetThreadExecutionState failed with Win32 error $lastError."
  }
}

function Get-ActiveFlags {
  $flags = [uint32]($ES_CONTINUOUS -bor $ES_SYSTEM_REQUIRED)
  if (-not $SystemOnly) {
    $flags = [uint32]($flags -bor $ES_DISPLAY_REQUIRED)
  }
  return $flags
}

function Get-RefreshFlags {
  $flags = [uint32]$ES_SYSTEM_REQUIRED
  if (-not $SystemOnly) {
    $flags = [uint32]($flags -bor $ES_DISPLAY_REQUIRED)
  }
  return $flags
}

function Get-ExistingKeepAwakeProcess {
  $escapedScriptPath = [Regex]::Escape($scriptPath)
  return Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
    Where-Object {
      $_.ProcessId -ne $PID -and
      $_.CommandLine -and
      $_.CommandLine -match $escapedScriptPath
    }
}

$existingProcess = Get-ExistingKeepAwakeProcess | Select-Object -First 1
if ($existingProcess) {
  Write-Host "Keep-awake is already running with PID $($existingProcess.ProcessId)."
  Write-Host "Use stop-keep-awake.cmd to stop it first."
  exit 1
}

$endTime = $null
if ($DurationSeconds -gt 0) {
  $endTime = (Get-Date).AddSeconds($DurationSeconds)
}

try {
  Invoke-ExecutionState -Flags (Get-ActiveFlags)

  Write-Host "Keep-awake is ON."
  if ($SystemOnly) {
    Write-Host "System sleep is blocked while this script runs."
  } else {
    Write-Host "System sleep and display sleep are blocked while this script runs."
  }
  Write-Host "You can minimize this window."
  Write-Host "Stop with Ctrl+C, close the window, or run stop-keep-awake.cmd."

  if ($endTime) {
    Write-Host ("Auto-stop time: {0}" -f $endTime.ToString("yyyy-MM-dd HH:mm:ss"))
  }

  while ($true) {
    Start-Sleep -Seconds $RefreshSeconds
    Invoke-ExecutionState -Flags (Get-RefreshFlags)

    if ($endTime -and (Get-Date) -ge $endTime) {
      break
    }
  }
}
finally {
  try {
    Invoke-ExecutionState -Flags ([uint32]$ES_CONTINUOUS)
  } catch {
  }

  Write-Host "Keep-awake is OFF."
}
