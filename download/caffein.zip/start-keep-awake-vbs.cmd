@echo off
set "FLAG=%~dp0keep-awake-vbs.running"

if exist "%FLAG%" (
  echo Keep-awake VBS is already marked as running.
  echo If it is not really running, use stop-keep-awake-vbs.cmd once and start again.
  exit /b 1
)

echo running>"%FLAG%"
start "" /min wscript.exe //nologo "%~dp0keep-awake.vbs"
echo Keep-awake VBS started.
echo Use stop-keep-awake-vbs.cmd to stop it.
