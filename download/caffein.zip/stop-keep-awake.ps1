$ErrorActionPreference = "Stop"
$scriptPath = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot "keep-awake.ps1"))
$escapedScriptPath = [Regex]::Escape($scriptPath)

$targets = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
  Where-Object {
    $_.CommandLine -and
    $_.CommandLine -match $escapedScriptPath
  }

if (-not $targets) {
  Write-Host "No running keep-awake process was found."
  exit 1
}

foreach ($target in $targets) {
  Stop-Process -Id $target.ProcessId -Force -ErrorAction Stop
}

Write-Host "Keep-awake stopped."
