Option Explicit

Dim shell, fso, folderPath, runFlagPath
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

folderPath = fso.GetParentFolderName(WScript.ScriptFullName)
runFlagPath = fso.BuildPath(folderPath, "keep-awake-vbs.running")

If Not fso.FileExists(runFlagPath) Then
  WScript.Quit 1
End If

Do While fso.FileExists(runFlagPath)
  shell.SendKeys "{F15}"
  WScript.Sleep 15000
Loop
