@echo off
start "" mshta.exe "%~dp0keep-awake.hta"
