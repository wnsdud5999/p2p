@echo off
start "Keep Awake" /min powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0keep-awake.ps1"
